create function st_snap(geom1 geometry, geom2 geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_Snap$$;

comment on function st_snap(geometry, geometry, double precision) is 'args: input, reference, tolerance - Snap segments and vertices of input geometry to vertices of a reference geometry.';

alter function st_snap(geometry, geometry, double precision) owner to postgres;

