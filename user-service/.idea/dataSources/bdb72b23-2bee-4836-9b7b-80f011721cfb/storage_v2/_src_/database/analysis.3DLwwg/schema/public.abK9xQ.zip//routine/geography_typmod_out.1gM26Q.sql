create function geography_typmod_out(integer) returns cstring
    immutable
    strict
    parallel safe
    language c
as
$$postgis_typmod_out$$;

alter function geography_typmod_out(integer) owner to postgres;

