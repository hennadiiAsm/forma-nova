create function geography_out(geography) returns cstring
    cost 100
    language c
as
$$geography_out$$;

