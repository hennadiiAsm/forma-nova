create function st_pointinsidecircle(geometry, double precision, double precision, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_inside_circle_point$$;

alter function st_pointinsidecircle(geometry, double precision, double precision, double precision) owner to postgres;

