create function geography_gist_picksplit(internal, internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_picksplit$$;

