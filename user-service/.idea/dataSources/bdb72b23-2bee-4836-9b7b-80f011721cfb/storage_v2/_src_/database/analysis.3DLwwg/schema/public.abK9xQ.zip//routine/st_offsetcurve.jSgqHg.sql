create function st_offsetcurve(line geometry, distance double precision, params text DEFAULT ''::text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_OffsetCurve$$;

comment on function st_offsetcurve(geometry, double precision, text) is 'args: line, signed_distance, style_parameters='' - Returns an offset line at a given distance and side from an input line.';

alter function st_offsetcurve(geometry, double precision, text) owner to postgres;

