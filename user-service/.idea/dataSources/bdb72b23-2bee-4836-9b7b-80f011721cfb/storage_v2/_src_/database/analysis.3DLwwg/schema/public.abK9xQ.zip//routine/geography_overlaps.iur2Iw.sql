create function geography_overlaps(geography, geography) returns boolean
    cost 100
    language c
as
$$gserialized_overlaps$$;

