create function st_makeenvelope(double precision, double precision, double precision, double precision, integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_MakeEnvelope$$;

comment on function st_makeenvelope(double precision, double precision, double precision, double precision, integer) is 'args: xmin, ymin, xmax, ymax, srid=unknown - Creates a rectangular Polygon from minimum and maximum coordinates.';

alter function st_makeenvelope(double precision, double precision, double precision, double precision, integer) owner to postgres;

