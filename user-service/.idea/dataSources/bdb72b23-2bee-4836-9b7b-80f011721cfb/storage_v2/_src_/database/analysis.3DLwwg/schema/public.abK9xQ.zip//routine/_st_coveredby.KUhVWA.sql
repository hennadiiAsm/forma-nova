create function _st_coveredby(geom1 geometry, geom2 geometry) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$coveredby$$;

alter function _st_coveredby(geometry, geometry) owner to postgres;

