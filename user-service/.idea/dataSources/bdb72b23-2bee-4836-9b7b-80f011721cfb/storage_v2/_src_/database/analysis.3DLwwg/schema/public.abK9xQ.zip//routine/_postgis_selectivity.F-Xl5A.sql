create function _postgis_selectivity(tbl regclass, att_name text, geom geometry, mode text DEFAULT '2'::text) returns double precision
    cost 100
    language c
as
$$_postgis_gserialized_sel$$;

