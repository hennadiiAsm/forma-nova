create function st_snaptogrid(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$SELECT public.ST_SnapToGrid($1, 0, 0, $2, $2)$$;

comment on function st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) is 'args: geomA, pointOrigin, sizeX, sizeY, sizeZ, sizeM - Snap all points of the input geometry to a regular grid.';

alter function st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) owner to postgres;

