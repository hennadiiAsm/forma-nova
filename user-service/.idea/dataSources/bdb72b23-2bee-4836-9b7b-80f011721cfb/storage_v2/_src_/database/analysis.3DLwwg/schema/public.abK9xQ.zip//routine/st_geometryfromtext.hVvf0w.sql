create function st_geometryfromtext(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_from_text$$;

alter function st_geometryfromtext(text, integer) owner to postgres;

