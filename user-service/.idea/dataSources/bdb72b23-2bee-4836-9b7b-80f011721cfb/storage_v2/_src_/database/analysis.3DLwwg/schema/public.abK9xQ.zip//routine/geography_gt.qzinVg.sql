create function geography_gt(geography, geography) returns boolean
    cost 100
    language c
as
$$geography_gt$$;

