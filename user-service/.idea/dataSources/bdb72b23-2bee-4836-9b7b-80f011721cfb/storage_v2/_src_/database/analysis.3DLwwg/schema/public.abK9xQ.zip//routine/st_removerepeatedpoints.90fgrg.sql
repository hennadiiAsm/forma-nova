create function st_removerepeatedpoints(geom geometry, tolerance double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_RemoveRepeatedPoints$$;

comment on function st_removerepeatedpoints(geometry, double precision) is 'args: geom, tolerance - Returns a version of a geometry with duplicate points removed.';

alter function st_removerepeatedpoints(geometry, double precision) owner to postgres;

