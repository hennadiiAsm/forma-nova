create function st_coverageunion(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$aggregate_dummy$$;

alter function st_coverageunion(geometry[]) owner to postgres;

