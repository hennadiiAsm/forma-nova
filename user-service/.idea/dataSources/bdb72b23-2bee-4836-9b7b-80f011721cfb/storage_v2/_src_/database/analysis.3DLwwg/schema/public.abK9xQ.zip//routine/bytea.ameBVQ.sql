create function bytea(geometry) returns bytea
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_bytea$$;

alter function bytea(geometry) owner to postgres;

