create function geography_cmp(geography, geography) returns integer
    cost 100
    language c
as
$$geography_cmp$$;

