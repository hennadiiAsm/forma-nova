create function st_simplifypolygonhull(geom geometry, vertex_fraction double precision, is_outer boolean DEFAULT true) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_SimplifyPolygonHull$$;

comment on function st_simplifypolygonhull(geometry, double precision, boolean) is 'args: param_geom, vertex_fraction, is_outer = true - Computes a simplifed topology-preserving outer or inner hull of a polygonal geometry.';

alter function st_simplifypolygonhull(geometry, double precision, boolean) owner to postgres;

