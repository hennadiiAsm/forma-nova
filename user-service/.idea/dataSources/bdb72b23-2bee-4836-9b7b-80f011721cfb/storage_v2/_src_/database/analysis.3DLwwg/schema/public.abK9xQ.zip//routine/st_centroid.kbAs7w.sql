create function st_centroid(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_Centroid($1::public.geometry);  $$;

comment on function st_centroid(geometry, bool) is 'args: g1 - Returns the geometric center of a geometry.';

alter function st_centroid(geometry, bool) owner to postgres;

