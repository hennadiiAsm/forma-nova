create function _st_voronoi(g1 geometry, clip geometry DEFAULT NULL::geometry, tolerance double precision DEFAULT 0.0, return_polygons boolean DEFAULT true) returns geometry
    immutable
    parallel safe
    cost 5000
    language c
as
$$ST_Voronoi$$;

alter function _st_voronoi(geometry, geometry, double precision, boolean) owner to postgres;

