create function st_asencodedpolyline(geom geometry, nprecision integer DEFAULT 5) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asEncodedPolyline$$;

alter function st_asencodedpolyline(geometry, integer) owner to postgres;

