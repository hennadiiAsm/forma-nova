create function geometry_above(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$gserialized_above_2d$$;

