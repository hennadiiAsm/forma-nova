create function _st_dwithin(geom1 geometry, geom2 geometry, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_dwithin$$;

alter function _st_dwithin(geography, geography, double precision, boolean) owner to postgres;

