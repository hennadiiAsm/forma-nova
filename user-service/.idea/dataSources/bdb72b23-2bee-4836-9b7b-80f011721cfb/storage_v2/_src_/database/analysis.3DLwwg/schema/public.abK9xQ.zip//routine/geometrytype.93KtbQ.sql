create function geometrytype(geometry) returns text
    immutable
    strict
    parallel safe
    language c
as
$$LWGEOM_getTYPE$$;

alter function geometrytype(geography) owner to postgres;

