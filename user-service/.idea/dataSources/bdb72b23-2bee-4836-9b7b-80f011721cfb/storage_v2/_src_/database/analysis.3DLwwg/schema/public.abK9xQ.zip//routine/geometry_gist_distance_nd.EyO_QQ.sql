create function geometry_gist_distance_nd(internal, geometry, integer) returns double precision
    parallel safe
    language c
as
$$gserialized_gist_distance$$;

alter function geometry_gist_distance_nd(internal, geometry, integer) owner to postgres;

