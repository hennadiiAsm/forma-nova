create function _st_sortablehash(geom geometry) returns bigint
    cost 100
    language c
as
$$_ST_SortableHash$$;

