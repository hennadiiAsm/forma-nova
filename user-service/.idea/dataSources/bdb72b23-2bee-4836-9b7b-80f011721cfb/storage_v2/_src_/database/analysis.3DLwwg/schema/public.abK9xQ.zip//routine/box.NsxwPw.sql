create function box(geometry) returns box
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_BOX$$;

alter function box(box3d) owner to postgres;

