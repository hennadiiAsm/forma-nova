create function st_azimuth(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_azimuth$$;

comment on function st_azimuth(geometry, geometry) is 'args: origin, target - Returns the north-based azimuth of a line between two points.';

alter function st_azimuth(geometry, geometry) owner to postgres;

