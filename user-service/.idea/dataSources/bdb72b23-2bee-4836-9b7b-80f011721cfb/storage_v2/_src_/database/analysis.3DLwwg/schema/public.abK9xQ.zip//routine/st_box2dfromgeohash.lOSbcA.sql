create function st_box2dfromgeohash(text, integer DEFAULT NULL::integer) returns box2d
    immutable
    parallel safe
    cost 50
    language c
as
$$box2d_from_geohash$$;

alter function st_box2dfromgeohash(text, integer) owner to postgres;

