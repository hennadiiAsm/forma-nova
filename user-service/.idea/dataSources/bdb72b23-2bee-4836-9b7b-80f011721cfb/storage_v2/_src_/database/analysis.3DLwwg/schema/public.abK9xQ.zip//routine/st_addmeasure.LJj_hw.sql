create function st_addmeasure(geometry, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_AddMeasure$$;

comment on function st_addmeasure(geometry, double precision, double precision) is 'args: geom_mline, measure_start, measure_end - Interpolates measures along a linear geometry.';

alter function st_addmeasure(geometry, double precision, double precision) owner to postgres;

