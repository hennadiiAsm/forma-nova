create function postgis_transform_geometry(geom geometry, text, text, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$transform_geom$$;

alter function postgis_transform_geometry(geometry, text, text, integer) owner to postgres;

