create function box2d_out(box2d) returns cstring
    cost 100
    language c
as
$$BOX2D_out$$;

