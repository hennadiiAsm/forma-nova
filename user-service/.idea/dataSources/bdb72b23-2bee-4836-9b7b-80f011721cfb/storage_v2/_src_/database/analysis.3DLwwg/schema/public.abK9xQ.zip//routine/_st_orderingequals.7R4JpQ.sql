create function _st_orderingequals(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$LWGEOM_same$$;

