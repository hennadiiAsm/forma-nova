create function st_clusterwithin(geometry, double precision) returns geometry[]
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$aggregate_dummy$$;

alter function st_clusterwithin(geometry[], double precision) owner to postgres;

