create function st_combinebbox(box3d, geometry) returns box3d
    immutable
    parallel safe
    cost 50
    language c
as
$$BOX3D_combine$$;

alter function st_combinebbox(box3d, geometry) owner to postgres;

