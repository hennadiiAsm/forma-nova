create function geometry_distance_cpa(geometry, geometry) returns double precision
    cost 100
    language c
as
$$ST_DistanceCPA$$;

