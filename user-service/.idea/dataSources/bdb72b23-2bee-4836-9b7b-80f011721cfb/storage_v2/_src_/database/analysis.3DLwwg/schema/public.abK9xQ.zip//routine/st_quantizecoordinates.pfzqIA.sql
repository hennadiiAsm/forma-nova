create function st_quantizecoordinates(g geometry, prec_x integer, prec_y integer DEFAULT NULL::integer, prec_z integer DEFAULT NULL::integer, prec_m integer DEFAULT NULL::integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$ST_QuantizeCoordinates$$;

comment on function st_quantizecoordinates(geometry, integer, integer, integer, integer) is 'args: g, prec_x, prec_y, prec_z, prec_m - Sets least significant bits of coordinates to zero';

alter function st_quantizecoordinates(geometry, integer, integer, integer, integer) owner to postgres;

