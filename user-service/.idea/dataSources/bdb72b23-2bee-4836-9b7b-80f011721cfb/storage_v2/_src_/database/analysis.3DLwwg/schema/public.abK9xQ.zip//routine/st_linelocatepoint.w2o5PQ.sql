create function st_linelocatepoint(text, text) returns double precision
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_LineLocatePoint($1::public.geometry, $2::public.geometry);  $$;

comment on function st_linelocatepoint(geography, geography, boolean) is 'args: a_linestring, a_point, use_spheroid = true - Returns the fractional location of the closest point on a line to a point.';

alter function st_linelocatepoint(geography, geography, boolean) owner to postgres;

