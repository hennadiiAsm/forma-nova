create function geography_in(cstring, oid, integer) returns geography
    immutable
    strict
    parallel safe
    language c
as
$$geography_in$$;

alter function geography_in(cstring, oid, integer) owner to postgres;

