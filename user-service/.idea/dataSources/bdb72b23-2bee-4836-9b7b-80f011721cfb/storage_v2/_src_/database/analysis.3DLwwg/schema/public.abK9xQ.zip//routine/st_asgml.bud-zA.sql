create function st_asgml(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asGML$$;

alter function st_asgml(geography, integer, integer, text, text, text) owner to postgres;

