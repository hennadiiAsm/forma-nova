create function st_covers(text, text) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_Covers($1::public.geometry, $2::public.geometry);  $$;

alter function st_covers(geography, geography) owner to postgres;

