create function _postgis_join_selectivity(regclass, text, regclass, text, text DEFAULT '2'::text) returns double precision
    cost 100
    language c
as
$$_postgis_gserialized_joinsel$$;

