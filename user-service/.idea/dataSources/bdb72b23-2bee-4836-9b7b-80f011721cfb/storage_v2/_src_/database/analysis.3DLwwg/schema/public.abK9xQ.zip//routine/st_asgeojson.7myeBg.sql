create function st_asgeojson(text) returns text
    stable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_AsGeoJson($1::public.geometry, 9, 0);  $$;

alter function st_asgeojson(record, text, integer, boolean) owner to postgres;

