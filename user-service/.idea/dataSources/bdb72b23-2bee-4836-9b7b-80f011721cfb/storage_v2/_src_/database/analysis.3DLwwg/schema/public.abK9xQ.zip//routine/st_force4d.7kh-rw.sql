create function st_force4d(geom geometry, zvalue double precision DEFAULT 0.0, mvalue double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_force_4d$$;

comment on function st_force4d(geometry, double precision, double precision) is 'args: geomA, Zvalue = 0.0, Mvalue = 0.0 - Force the geometries into XYZM mode.';

alter function st_force4d(geometry, double precision, double precision) owner to postgres;

