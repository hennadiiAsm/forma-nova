create function geometry_gist_distance_2d(internal, geometry, integer) returns double precision
    parallel safe
    language c
as
$$gserialized_gist_distance_2d$$;

alter function geometry_gist_distance_2d(internal, geometry, integer) owner to postgres;

