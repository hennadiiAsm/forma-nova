create function box2df_out(box2df) returns cstring
    cost 100
    language c
as
$$box2df_out$$;

