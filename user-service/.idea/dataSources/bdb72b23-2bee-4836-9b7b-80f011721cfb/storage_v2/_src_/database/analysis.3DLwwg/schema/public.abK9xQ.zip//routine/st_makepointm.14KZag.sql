create function st_makepointm(double precision, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_makepoint3dm$$;

comment on function st_makepointm(double precision, double precision, double precision) is 'args: x, y, m - Creates a Point from X, Y and M values.';

alter function st_makepointm(double precision, double precision, double precision) owner to postgres;

