create function st_asgml(geom geometry, maxdecimaldigits integer DEFAULT 15, options integer DEFAULT 0) returns text
    immutable
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asGML$$;

alter function st_asgml(geometry, integer, integer, text, text) owner to postgres;

