create function st_boundingdiagonal(geom geometry, fits boolean DEFAULT false) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ST_BoundingDiagonal$$;

comment on function st_boundingdiagonal(geometry, boolean) is 'args: geom, fits=false - Returns the diagonal of a geometrys bounding box.';

alter function st_boundingdiagonal(geometry, boolean) owner to postgres;

