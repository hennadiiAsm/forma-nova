create function geography_analyze(internal) returns boolean
    cost 100
    language c
as
$$gserialized_analyze_nd$$;

