create function st_chaikinsmoothing(geometry, integer DEFAULT 1, boolean DEFAULT false) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_ChaikinSmoothing$$;

comment on function st_chaikinsmoothing(geometry, integer, boolean) is 'args: geom, nIterations = 1, preserveEndPoints = false - Returns a smoothed version of a geometry, using the Chaikin algorithm';

alter function st_chaikinsmoothing(geometry, integer, boolean) owner to postgres;

