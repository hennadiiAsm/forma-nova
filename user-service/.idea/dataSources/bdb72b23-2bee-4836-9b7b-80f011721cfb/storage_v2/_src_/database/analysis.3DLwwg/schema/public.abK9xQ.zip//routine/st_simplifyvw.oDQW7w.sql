create function st_simplifyvw(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_SetEffectiveArea$$;

comment on function st_simplifyvw(geometry, double precision) is 'args: geomA, tolerance - Returns a simplified version of a geometry, using the Visvalingam-Whyatt algorithm';

alter function st_simplifyvw(geometry, double precision) owner to postgres;

