create function st_dwithin(text, text, double precision) returns boolean
    immutable
    parallel safe
    language sql
as
$$ SELECT public.ST_DWithin($1::public.geometry, $2::public.geometry, $3);  $$;

alter function st_dwithin(text, text, double precision) owner to postgres;

