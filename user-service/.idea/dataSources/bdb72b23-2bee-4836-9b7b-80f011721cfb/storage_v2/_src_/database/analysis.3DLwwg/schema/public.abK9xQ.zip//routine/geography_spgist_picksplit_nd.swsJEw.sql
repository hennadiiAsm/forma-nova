create function geography_spgist_picksplit_nd(internal, internal) returns void
    cost 100
    language c
as
$$gserialized_spgist_picksplit_nd$$;

