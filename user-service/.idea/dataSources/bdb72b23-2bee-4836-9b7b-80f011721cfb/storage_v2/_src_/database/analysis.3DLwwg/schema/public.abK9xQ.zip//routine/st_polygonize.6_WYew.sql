create function st_polygonize(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$aggregate_dummy$$;

comment on function st_polygonize(geometry[]) is 'args: geom_array - Computes a collection of polygons formed from the linework of a set of geometries.';

alter function st_polygonize(geometry[]) owner to postgres;

