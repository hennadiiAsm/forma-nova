create function _st_asx3d(integer, geometry, integer, integer, text) returns text
    immutable
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asX3D$$;

alter function _st_asx3d(integer, geometry, integer, integer, text) owner to postgres;

