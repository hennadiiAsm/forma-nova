create function st_srid(geom geometry) returns integer
    immutable
    strict
    parallel safe
    language c
as
$$LWGEOM_get_srid$$;

comment on function st_srid(geometry) is 'args: g1 - Returns the spatial reference identifier for a geometry.';

alter function st_srid(geometry) owner to postgres;

