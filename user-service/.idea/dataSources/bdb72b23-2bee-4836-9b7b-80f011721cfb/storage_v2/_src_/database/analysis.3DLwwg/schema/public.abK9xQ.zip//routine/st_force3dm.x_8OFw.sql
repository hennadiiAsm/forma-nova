create function st_force3dm(geom geometry, mvalue double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_force_3dm$$;

comment on function st_force3dm(geometry, double precision) is 'args: geomA, Mvalue = 0.0 - Force the geometries into XYM mode.';

alter function st_force3dm(geometry, double precision) owner to postgres;

