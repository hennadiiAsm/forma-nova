create function st_3ddwithin(geom1 geometry, geom2 geometry, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_dwithin3d$$;

alter function st_3ddwithin(geometry, geometry, double precision) owner to postgres;

