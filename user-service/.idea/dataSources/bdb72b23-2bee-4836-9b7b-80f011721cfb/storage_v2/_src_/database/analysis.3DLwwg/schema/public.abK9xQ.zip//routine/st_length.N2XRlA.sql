create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ SELECT public.ST_Length($1::public.geometry);  $$;

comment on function st_length(geometry, bool) is 'args: a_2dlinestring - Returns the 2D length of a linear geometry.';

alter function st_length(geometry, bool) owner to postgres;

