create function st_distancespheroid(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_distance_ellipsoid$$;

alter function st_distancespheroid(geometry, geometry, spheroid) owner to postgres;

