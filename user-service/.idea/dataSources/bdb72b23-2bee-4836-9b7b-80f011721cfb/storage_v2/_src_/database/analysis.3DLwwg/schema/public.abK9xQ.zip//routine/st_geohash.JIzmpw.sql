create function st_geohash(geom geometry, maxchars integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_GeoHash$$;

alter function st_geohash(geometry, integer) owner to postgres;

