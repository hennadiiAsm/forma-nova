create function st_summary(geometry) returns text
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_summary$$;

comment on function st_summary(geometry) is 'args: g - Returns a text summary of the contents of a geometry.';

alter function st_summary(geometry) owner to postgres;

