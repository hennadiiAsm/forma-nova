create function bytea(geometry) returns bytea
    immutable
    strict
    parallel safe
    language c
as
$$LWGEOM_to_bytea$$;

alter function bytea(geography) owner to postgres;

