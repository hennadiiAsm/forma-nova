create function st_curvetoline(geom geometry, tol double precision DEFAULT 32, toltype integer DEFAULT 0, flags integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_CurveToLine$$;

comment on function st_curvetoline(geometry, double precision, integer, integer) is 'args: curveGeom, tolerance, tolerance_type, flags - Converts a geometry containing curves to a linear geometry.';

alter function st_curvetoline(geometry, double precision, integer, integer) owner to postgres;

