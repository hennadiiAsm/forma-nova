create function st_seteffectivearea(geometry, double precision DEFAULT '-1'::integer, integer DEFAULT 1) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_SetEffectiveArea$$;

comment on function st_seteffectivearea(geometry, double precision, integer) is 'args: geomA, threshold = 0, set_area = 1 - Sets the effective area for each vertex, using the Visvalingam-Whyatt algorithm.';

alter function st_seteffectivearea(geometry, double precision, integer) owner to postgres;

