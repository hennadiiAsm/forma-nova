create function dropgeometrytable(table_name character varying) returns text
    strict
    language sql
as
$$ SELECT public.DropGeometryTable('','',$1) $$;

comment on function dropgeometrytable(varchar, varchar, varchar) is 'args: table_name - Drops a table and all its references in geometry_columns.';

alter function dropgeometrytable(varchar, varchar, varchar) owner to postgres;

