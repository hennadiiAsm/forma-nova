create function geometry_gist_picksplit_2d(internal, internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_picksplit_2d$$;

