create function st_setsrid(geom geometry, srid integer) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$LWGEOM_set_srid$$;

comment on function st_setsrid(geometry, integer) is 'args: geom, srid - Set the SRID on a geometry.';

alter function st_setsrid(geometry, integer) owner to postgres;

