create function checkauthtrigger() returns trigger
    cost 100
    language c
as
$$check_authorization$$;

