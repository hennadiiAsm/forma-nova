create function st_pointm(xcoordinate double precision, ycoordinate double precision, mcoordinate double precision, srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_PointM$$;

comment on function st_pointm(double precision, double precision, double precision, integer) is 'args: x, y, m, srid=unknown - Creates a Point with X, Y, M and SRID values.';

alter function st_pointm(double precision, double precision, double precision, integer) owner to postgres;

