create function postgis_typmod_type(integer) returns text
    immutable
    strict
    parallel safe
    language c
as
$$postgis_typmod_type$$;

alter function postgis_typmod_type(integer) owner to postgres;

