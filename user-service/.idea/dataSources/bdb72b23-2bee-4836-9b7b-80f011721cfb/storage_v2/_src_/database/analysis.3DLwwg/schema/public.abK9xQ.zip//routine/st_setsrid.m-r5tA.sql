create function st_setsrid(geom geometry, srid integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_set_srid$$;

alter function st_setsrid(geography, integer) owner to postgres;

