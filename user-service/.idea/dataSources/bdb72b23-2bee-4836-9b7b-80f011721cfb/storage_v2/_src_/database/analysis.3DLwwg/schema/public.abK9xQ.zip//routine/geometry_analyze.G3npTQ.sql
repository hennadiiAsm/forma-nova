create function geometry_analyze(internal) returns boolean
    cost 100
    language c
as
$$gserialized_analyze_nd$$;

