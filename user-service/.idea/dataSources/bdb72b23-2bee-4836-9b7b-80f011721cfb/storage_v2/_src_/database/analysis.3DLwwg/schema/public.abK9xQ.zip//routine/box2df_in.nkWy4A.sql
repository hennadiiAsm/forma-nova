create function box2df_in(cstring) returns box2df
    cost 100
    language c
as
$$box2df_in$$;

