create function geography_le(geography, geography) returns boolean
    cost 100
    language c
as
$$geography_le$$;

