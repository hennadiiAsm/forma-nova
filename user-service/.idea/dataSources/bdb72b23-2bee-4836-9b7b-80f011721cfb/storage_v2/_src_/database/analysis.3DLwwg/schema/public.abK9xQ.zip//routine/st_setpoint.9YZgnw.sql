create function st_setpoint(geometry, integer, geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_setpoint_linestring$$;

comment on function st_setpoint(geometry, integer, geometry) is 'args: linestring, zerobasedposition, point - Replace point of a linestring with a given point.';

alter function st_setpoint(geometry, integer, geometry) owner to postgres;

