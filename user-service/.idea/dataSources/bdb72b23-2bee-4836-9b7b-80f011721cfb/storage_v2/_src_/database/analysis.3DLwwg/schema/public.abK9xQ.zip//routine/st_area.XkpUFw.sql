create function st_area(text) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ SELECT public.ST_Area($1::public.geometry);  $$;

comment on function st_area(geometry, bool) is 'args: g1 - Returns the area of a polygonal geometry.';

alter function st_area(geometry, bool) owner to postgres;

