create function st_simplify(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_simplify2d$$;

comment on function st_simplify(geometry, double precision, boolean) is 'args: geomA, tolerance, preserveCollapsed - Returns a simplified version of a geometry, using the Douglas-Peucker algorithm.';

alter function st_simplify(geometry, double precision, boolean) owner to postgres;

