create function st_lineinterpolatepoints(text, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_LineInterpolatePoints($1::public.geometry, $2);  $$;

comment on function st_lineinterpolatepoints(geometry, double precision, boolean) is 'args: a_linestring, a_fraction, repeat - Returns points interpolated along a line at a fractional interval.';

alter function st_lineinterpolatepoints(geometry, double precision, boolean) owner to postgres;

