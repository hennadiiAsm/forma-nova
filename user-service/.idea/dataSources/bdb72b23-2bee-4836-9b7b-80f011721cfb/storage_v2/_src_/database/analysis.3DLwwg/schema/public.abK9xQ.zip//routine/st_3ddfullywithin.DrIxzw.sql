create function st_3ddfullywithin(geom1 geometry, geom2 geometry, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_dfullywithin3d$$;

alter function st_3ddfullywithin(geometry, geometry, double precision) owner to postgres;

