create function box2d(geometry) returns box2d
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_BOX2D$$;

alter function box2d(box3d) owner to postgres;

