create function st_asbinary(geometry) returns bytea
    immutable
    parallel safe
    cost 50
    language c
as
$$LWGEOM_asBinary$$;

alter function st_asbinary(geography, text) owner to postgres;

