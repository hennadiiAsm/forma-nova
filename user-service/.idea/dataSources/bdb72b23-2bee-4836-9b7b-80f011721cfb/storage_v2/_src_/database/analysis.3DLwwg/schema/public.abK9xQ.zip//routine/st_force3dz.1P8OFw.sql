create function st_force3dz(geom geometry, zvalue double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_force_3dz$$;

comment on function st_force3dz(geometry, double precision) is 'args: geomA, Zvalue = 0.0 - Force the geometries into XYZ mode.';

alter function st_force3dz(geometry, double precision) owner to postgres;

