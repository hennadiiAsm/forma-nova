create function geography_gist_decompress(internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_decompress$$;

