create function geometry_gist_consistent_nd(internal, geometry, integer) returns boolean
    parallel safe
    language c
as
$$gserialized_gist_consistent$$;

alter function geometry_gist_consistent_nd(internal, geometry, integer) owner to postgres;

