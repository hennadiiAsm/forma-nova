create function geometry_typmod_in(cstring[]) returns integer
    immutable
    strict
    parallel safe
    language c
as
$$geometry_typmod_in$$;

alter function geometry_typmod_in(cstring[]) owner to postgres;

