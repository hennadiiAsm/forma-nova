create function st_shortestline(text, text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_ShortestLine($1::public.geometry, $2::public.geometry);  $$;

comment on function st_shortestline(geometry, geometry, bool) is 'args: geom1, geom2 - Returns the 2D shortest line between two geometries';

alter function st_shortestline(geometry, geometry, bool) owner to postgres;

