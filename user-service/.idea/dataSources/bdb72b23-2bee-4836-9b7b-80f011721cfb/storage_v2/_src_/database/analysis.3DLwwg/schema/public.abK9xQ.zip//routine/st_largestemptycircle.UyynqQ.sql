create function st_largestemptycircle(geom geometry, tolerance double precision DEFAULT 0.0, boundary geometry DEFAULT '0101000000000000000000F87F000000000000F87F'::geometry, OUT center geometry, OUT nearest geometry, OUT radius double precision) returns record
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_LargestEmptyCircle$$;

comment on function st_largestemptycircle(geometry, double precision, geometry, out geometry, out geometry, out double precision) is 'args: geom, tolerance=0.0, boundary=POINT EMPTY - Computes the largest circle not overlapping a geometry.';

alter function st_largestemptycircle(geometry, double precision, geometry, out geometry, out geometry, out double precision) owner to postgres;

