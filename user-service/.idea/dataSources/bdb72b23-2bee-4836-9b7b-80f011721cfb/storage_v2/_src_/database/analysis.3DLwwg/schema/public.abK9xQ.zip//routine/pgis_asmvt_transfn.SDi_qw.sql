create function pgis_asmvt_transfn(internal, anyelement) returns internal
    immutable
    parallel safe
    cost 250
    language c
as
$$pgis_asmvt_transfn$$;

alter function pgis_asmvt_transfn(internal, anyelement, text, integer, text) owner to postgres;

