create function gserialized_gist_sel_nd(internal, oid, internal, integer) returns double precision
    parallel safe
    language c
as
$$gserialized_gist_sel_nd$$;

alter function gserialized_gist_sel_nd(internal, oid, internal, integer) owner to postgres;

