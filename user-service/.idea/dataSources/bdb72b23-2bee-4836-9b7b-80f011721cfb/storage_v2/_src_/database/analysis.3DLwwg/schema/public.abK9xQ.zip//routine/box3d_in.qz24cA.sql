create function box3d_in(cstring) returns box3d
    cost 100
    language c
as
$$BOX3D_in$$;

