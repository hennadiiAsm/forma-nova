create function st_squaregrid(size double precision, bounds geometry, OUT geom geometry, OUT i integer, OUT j integer) returns SETOF record
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_ShapeGrid$$;

comment on function st_squaregrid(double precision, geometry, out geometry, out integer, out integer) is 'args: size, bounds - Returns a set of grid squares and cell indices that completely cover the bounds of the geometry argument.';

alter function st_squaregrid(double precision, geometry, out geometry, out integer, out integer) owner to postgres;

