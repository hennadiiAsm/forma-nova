create function st_transform(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$transform$$;

comment on function st_transform(geometry, integer) is 'args: g1, srid - Return a new geometry with coordinates transformed to a different spatial reference system.';

alter function st_transform(geometry, integer) owner to postgres;

