create function st_segmentize(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_segmentize2d$$;

comment on function st_segmentize(geography, double precision) is 'args: geog, max_segment_length - Returns a modified geometry/geography having no segment longer than a given distance.';

alter function st_segmentize(geography, double precision) owner to postgres;

