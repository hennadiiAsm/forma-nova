create function st_unaryunion(geometry, gridsize double precision DEFAULT '-1.0'::numeric) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_UnaryUnion$$;

comment on function st_unaryunion(geometry, double precision) is 'args: geom, gridSize = -1 - Computes the union of the components of a single geometry.';

alter function st_unaryunion(geometry, double precision) owner to postgres;

