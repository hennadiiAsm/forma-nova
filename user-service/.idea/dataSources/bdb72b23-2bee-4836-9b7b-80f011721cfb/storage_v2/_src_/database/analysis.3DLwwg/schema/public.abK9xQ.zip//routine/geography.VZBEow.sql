create function geography(bytea) returns geography
    immutable
    strict
    parallel safe
    language c
as
$$geography_from_binary$$;

alter function geography(geography, integer, boolean) owner to postgres;

