create function st_relate(geom1 geometry, geom2 geometry) returns text
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$relate_full$$;

alter function st_relate(geometry, geometry, integer) owner to postgres;

