create function st_astwkb(geom geometry, prec integer DEFAULT NULL::integer, prec_z integer DEFAULT NULL::integer, prec_m integer DEFAULT NULL::integer, with_sizes boolean DEFAULT NULL::boolean, with_boxes boolean DEFAULT NULL::boolean) returns bytea
    immutable
    parallel safe
    cost 50
    language c
as
$$TWKBFromLWGEOM$$;

alter function st_astwkb(geometry, integer, integer, integer, boolean, boolean, bool) owner to postgres;

