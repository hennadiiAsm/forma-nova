create function st_linefromencodedpolyline(txtin text, nprecision integer DEFAULT 5) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$line_from_encoded_polyline$$;

alter function st_linefromencodedpolyline(text, integer) owner to postgres;

