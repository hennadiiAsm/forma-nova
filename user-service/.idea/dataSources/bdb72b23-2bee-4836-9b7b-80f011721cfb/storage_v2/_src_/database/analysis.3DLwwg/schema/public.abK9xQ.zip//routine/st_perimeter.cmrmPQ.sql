create function st_perimeter(geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_perimeter2d_poly$$;

comment on function st_perimeter(geometry, bool) is 'args: g1 - Returns the length of the boundary of a polygonal geometry or geography.';

alter function st_perimeter(geometry, bool) owner to postgres;

