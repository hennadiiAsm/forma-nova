create function st_collect(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$aggregate_dummy$$;

comment on function st_collect(geometry[], geometry) is 'args: g1_array - Creates a GeometryCollection or Multi* geometry from a set of geometries.';

alter function st_collect(geometry[], geometry) owner to postgres;

