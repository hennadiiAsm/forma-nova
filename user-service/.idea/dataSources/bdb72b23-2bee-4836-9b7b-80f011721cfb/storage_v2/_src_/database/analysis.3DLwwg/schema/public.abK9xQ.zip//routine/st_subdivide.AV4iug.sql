create function st_subdivide(geom geometry, maxvertices integer DEFAULT 256, gridsize double precision DEFAULT '-1.0'::numeric) returns SETOF geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_Subdivide$$;

comment on function st_subdivide(geometry, integer, double precision) is 'args: geom, max_vertices=256, gridSize = -1 - Computes a rectilinear subdivision of a geometry.';

alter function st_subdivide(geometry, integer, double precision) owner to postgres;

