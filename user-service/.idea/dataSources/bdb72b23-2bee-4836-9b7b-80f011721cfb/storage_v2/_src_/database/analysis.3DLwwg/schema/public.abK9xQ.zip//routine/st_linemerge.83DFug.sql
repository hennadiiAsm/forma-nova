create function st_linemerge(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$linemerge$$;

comment on function st_linemerge(geometry, boolean) is 'args: amultilinestring, directed - Return the lines formed by sewing together a MultiLineString.';

alter function st_linemerge(geometry, boolean) owner to postgres;

