create function _postgis_stats(tbl regclass, att_name text, text DEFAULT '2'::text) returns text
    cost 100
    language c
as
$$_postgis_gserialized_stats$$;

