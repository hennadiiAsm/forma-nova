create function st_filterbym(geometry, double precision, double precision DEFAULT NULL::double precision, boolean DEFAULT false) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$LWGEOM_FilterByM$$;

comment on function st_filterbym(geometry, double precision, double precision, boolean) is 'args: geom, min, max = null, returnM = false - Removes vertices based on their M value';

alter function st_filterbym(geometry, double precision, double precision, boolean) owner to postgres;

