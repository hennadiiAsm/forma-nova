create function st_collectionextract(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_CollectionExtract$$;

comment on function st_collectionextract(geometry, integer) is 'args: collection, type - Given a geometry collection, returns a multi-geometry containing only elements of a specified type.';

alter function st_collectionextract(geometry, integer) owner to postgres;

