create function geography_typmod_in(cstring[]) returns integer
    immutable
    strict
    parallel safe
    language c
as
$$geography_typmod_in$$;

alter function geography_typmod_in(cstring[]) owner to postgres;

