create function box3d(geometry) returns box3d
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_BOX3D$$;

comment on function box3d(geometry) is 'args: geom - Returns a BOX3D representing the 3D extent of a geometry.';

alter function box3d(geometry) owner to postgres;

