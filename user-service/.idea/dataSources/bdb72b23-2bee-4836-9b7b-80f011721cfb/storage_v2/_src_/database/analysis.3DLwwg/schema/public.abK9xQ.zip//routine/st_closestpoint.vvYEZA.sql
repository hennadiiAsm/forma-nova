create function st_closestpoint(text, text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_ClosestPoint($1::public.geometry, $2::public.geometry);  $$;

comment on function st_closestpoint(geometry, geometry, bool) is 'args: geom1, geom2 - Returns the 2D point on g1 that is closest to g2. This is the first point of the shortest line from one geometry to the other.';

alter function st_closestpoint(geometry, geometry, bool) owner to postgres;

