create function st_length(text) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_Length($1::public.geometry);  $$;

comment on function st_length(geography, boolean) is 'args: geog, use_spheroid = true - Returns the 2D length of a linear geometry.';

alter function st_length(geography, boolean) owner to postgres;

