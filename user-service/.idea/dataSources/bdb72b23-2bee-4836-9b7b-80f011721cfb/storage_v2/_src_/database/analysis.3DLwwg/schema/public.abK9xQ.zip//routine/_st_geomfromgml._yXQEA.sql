create function _st_geomfromgml(text, integer) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$geom_from_gml$$;

alter function _st_geomfromgml(text, integer) owner to postgres;

