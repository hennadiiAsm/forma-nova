create function st_addpoint(geom1 geometry, geom2 geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_addpoint$$;

comment on function st_addpoint(geometry, geometry, integer) is 'args: linestring, point, position = -1 - Add a point to a LineString.';

alter function st_addpoint(geometry, geometry, integer) owner to postgres;

