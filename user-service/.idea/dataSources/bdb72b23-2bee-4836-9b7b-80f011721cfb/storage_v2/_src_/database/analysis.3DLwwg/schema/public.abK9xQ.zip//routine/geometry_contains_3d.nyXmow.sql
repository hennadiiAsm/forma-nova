create function geometry_contains_3d(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$gserialized_contains_3d$$;

