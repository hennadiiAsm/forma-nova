create function st_expand(box2d, double precision) returns box2d
    immutable
    strict
    parallel safe
    language c
as
$$BOX2D_expand$$;

comment on function st_expand(box2d, double precision, double precision) is 'args: box, dx, dy - Returns a bounding box expanded from another bounding box or a geometry.';

alter function st_expand(box2d, double precision, double precision) owner to postgres;

