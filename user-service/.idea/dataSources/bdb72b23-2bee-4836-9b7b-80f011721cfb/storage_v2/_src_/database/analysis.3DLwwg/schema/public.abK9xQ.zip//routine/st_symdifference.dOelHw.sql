create function st_symdifference(geom1 geometry, geom2 geometry, gridsize double precision DEFAULT '-1.0'::numeric) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_SymDifference$$;

comment on function st_symdifference(geometry, geometry, double precision) is 'args: geomA, geomB, gridSize = -1 - Computes a geometry representing the portions of geometries A and B that do not intersect.';

alter function st_symdifference(geometry, geometry, double precision) owner to postgres;

