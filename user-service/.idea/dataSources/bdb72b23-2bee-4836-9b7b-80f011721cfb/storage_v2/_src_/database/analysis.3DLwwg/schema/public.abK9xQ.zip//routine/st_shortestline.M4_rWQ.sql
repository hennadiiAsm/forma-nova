create function st_shortestline(text, text) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_ShortestLine($1::public.geometry, $2::public.geometry);  $$;

comment on function st_shortestline(geography, geography, boolean) is 'args: geom1, geom2, use_spheroid = true - Returns the 2D shortest line between two geometries';

alter function st_shortestline(geography, geography, boolean) owner to postgres;

