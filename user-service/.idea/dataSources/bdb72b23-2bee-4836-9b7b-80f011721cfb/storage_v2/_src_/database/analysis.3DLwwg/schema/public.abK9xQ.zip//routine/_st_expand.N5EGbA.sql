create function _st_expand(geography, double precision) returns geography
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$geography_expand$$;

alter function _st_expand(geography, double precision) owner to postgres;

