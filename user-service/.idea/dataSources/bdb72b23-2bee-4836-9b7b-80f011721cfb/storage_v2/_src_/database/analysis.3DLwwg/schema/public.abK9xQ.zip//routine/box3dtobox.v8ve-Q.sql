create function box3dtobox(box3d) returns box
    cost 100
    language c
as
$$BOX3D_to_BOX$$;

