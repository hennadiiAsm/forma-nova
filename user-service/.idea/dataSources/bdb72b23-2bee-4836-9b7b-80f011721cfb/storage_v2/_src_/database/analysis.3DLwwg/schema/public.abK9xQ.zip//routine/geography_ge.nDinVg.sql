create function geography_ge(geography, geography) returns boolean
    cost 100
    language c
as
$$geography_ge$$;

