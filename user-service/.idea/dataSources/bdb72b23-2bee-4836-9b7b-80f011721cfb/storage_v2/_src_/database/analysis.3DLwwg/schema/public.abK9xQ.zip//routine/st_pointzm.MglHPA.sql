create function st_pointzm(xcoordinate double precision, ycoordinate double precision, zcoordinate double precision, mcoordinate double precision, srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_PointZM$$;

comment on function st_pointzm(double precision, double precision, double precision, double precision, integer) is 'args: x, y, z, m, srid=unknown - Creates a Point with X, Y, Z, M and SRID values.';

alter function st_pointzm(double precision, double precision, double precision, double precision, integer) owner to postgres;

