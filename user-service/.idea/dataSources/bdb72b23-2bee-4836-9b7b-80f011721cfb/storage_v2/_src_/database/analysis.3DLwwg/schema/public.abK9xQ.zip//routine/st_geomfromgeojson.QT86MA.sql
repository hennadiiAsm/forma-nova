create function st_geomfromgeojson(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$geom_from_geojson$$;

alter function st_geomfromgeojson(text) owner to postgres;

