create function st_perimeter(geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_perimeter2d_poly$$;

comment on function st_perimeter(geography, boolean) is 'args: geog, use_spheroid = true - Returns the length of the boundary of a polygonal geometry or geography.';

alter function st_perimeter(geography, boolean) owner to postgres;

