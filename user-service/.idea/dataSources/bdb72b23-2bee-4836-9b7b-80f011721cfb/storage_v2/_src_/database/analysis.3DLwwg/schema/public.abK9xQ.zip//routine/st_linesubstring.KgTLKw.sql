create function st_linesubstring(text, double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_LineSubstring($1::public.geometry, $2, $3);  $$;

comment on function st_linesubstring(geography, double precision, double precision) is 'args: a_linestring, startfraction, endfraction - Returns the part of a line between two fractional locations.';

alter function st_linesubstring(geography, double precision, double precision) owner to postgres;

