create function geometry(geometry, integer, boolean) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$geometry_enforce_typmod$$;

alter function geometry(geography) owner to postgres;

