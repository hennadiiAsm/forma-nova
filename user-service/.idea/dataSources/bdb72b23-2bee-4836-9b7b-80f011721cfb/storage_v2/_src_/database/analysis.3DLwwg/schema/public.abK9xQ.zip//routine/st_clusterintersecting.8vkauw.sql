create function st_clusterintersecting(geometry) returns geometry[]
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$aggregate_dummy$$;

alter function st_clusterintersecting(geometry[]) owner to postgres;

