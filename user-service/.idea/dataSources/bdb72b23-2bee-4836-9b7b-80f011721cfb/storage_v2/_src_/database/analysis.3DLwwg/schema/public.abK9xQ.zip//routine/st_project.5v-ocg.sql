create function st_project(geom1 geometry, distance double precision, azimuth double precision) returns geometry
    immutable
    parallel safe
    cost 250
    language c
as
$$geometry_project_direction$$;

comment on function st_project(geography, double precision, double precision) is 'args: g1, distance, azimuth - Returns a point projected from a start point by a distance and bearing (azimuth).';

alter function st_project(geography, double precision, double precision) owner to postgres;

