create function pgis_geometry_accum_transfn(internal, geometry) returns internal
    parallel safe
    cost 50
    language c
as
$$pgis_geometry_accum_transfn$$;

alter function pgis_geometry_accum_transfn(internal, geometry, double precision) owner to postgres;

