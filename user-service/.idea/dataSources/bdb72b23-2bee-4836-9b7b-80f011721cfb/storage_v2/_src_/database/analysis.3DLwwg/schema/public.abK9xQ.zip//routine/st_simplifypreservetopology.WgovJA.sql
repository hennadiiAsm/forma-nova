create function st_simplifypreservetopology(geometry, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$topologypreservesimplify$$;

comment on function st_simplifypreservetopology(geometry, double precision) is 'args: geomA, tolerance - Returns a simplified and valid version of a geometry, using the Douglas-Peucker algorithm.';

alter function st_simplifypreservetopology(geometry, double precision) owner to postgres;

