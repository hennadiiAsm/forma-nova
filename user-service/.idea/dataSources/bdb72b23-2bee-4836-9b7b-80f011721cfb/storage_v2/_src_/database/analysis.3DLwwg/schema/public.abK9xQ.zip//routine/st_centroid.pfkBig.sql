create function st_centroid(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_Centroid($1::public.geometry);  $$;

comment on function st_centroid(geography, boolean) is 'args: g1, use_spheroid = true - Returns the geometric center of a geometry.';

alter function st_centroid(geography, boolean) owner to postgres;

