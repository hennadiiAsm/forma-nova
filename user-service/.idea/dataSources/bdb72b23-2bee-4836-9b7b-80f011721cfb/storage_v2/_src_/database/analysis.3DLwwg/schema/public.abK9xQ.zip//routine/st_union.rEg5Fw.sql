create function st_union(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$aggregate_dummy$$;

comment on function st_union(geometry, geometry) is 'args: g1, g2 - Computes a geometry representing the point-set union of the input geometries.';

alter function st_union(geometry, geometry) owner to postgres;

