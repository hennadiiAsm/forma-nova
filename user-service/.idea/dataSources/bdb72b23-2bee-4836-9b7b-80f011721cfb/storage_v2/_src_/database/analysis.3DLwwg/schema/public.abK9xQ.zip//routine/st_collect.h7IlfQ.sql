create function st_collect(geometry) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$aggregate_dummy$$;

comment on function st_collect(geometry, geometry) is 'args: g1, g2 - Creates a GeometryCollection or Multi* geometry from a set of geometries.';

alter function st_collect(geometry, geometry) owner to postgres;

