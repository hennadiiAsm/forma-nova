create function st_delaunaytriangles(g1 geometry, tolerance double precision DEFAULT 0.0, flags integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_DelaunayTriangles$$;

comment on function st_delaunaytriangles(geometry, double precision, integer) is 'args: g1, tolerance = 0.0, flags = 0 - Returns the Delaunay triangulation of the vertices of a geometry.';

alter function st_delaunaytriangles(geometry, double precision, integer) owner to postgres;

