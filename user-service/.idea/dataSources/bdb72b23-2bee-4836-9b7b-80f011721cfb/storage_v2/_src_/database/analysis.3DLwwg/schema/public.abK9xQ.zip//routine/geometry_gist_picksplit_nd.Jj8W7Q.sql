create function geometry_gist_picksplit_nd(internal, internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_picksplit$$;

