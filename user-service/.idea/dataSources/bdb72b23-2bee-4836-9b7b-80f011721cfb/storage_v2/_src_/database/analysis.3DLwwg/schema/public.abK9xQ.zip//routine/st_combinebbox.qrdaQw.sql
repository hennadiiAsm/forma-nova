create function st_combinebbox(box3d, geometry) returns box3d
    immutable
    parallel safe
    language c
as
$$BOX3D_combine$$;

alter function st_combinebbox(box2d, geometry) owner to postgres;

