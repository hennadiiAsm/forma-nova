create function geometry_eq(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$lwgeom_eq$$;

