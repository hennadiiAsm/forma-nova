create function geometry_contained_3d(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$gserialized_contained_3d$$;

