create function st_lineinterpolatepoint(text, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_LineInterpolatePoint($1::public.geometry, $2);  $$;

comment on function st_lineinterpolatepoint(geometry, double precision, bool) is 'args: a_linestring, a_fraction - Returns a point interpolated along a line at a fractional location.';

alter function st_lineinterpolatepoint(geometry, double precision, bool) owner to postgres;

