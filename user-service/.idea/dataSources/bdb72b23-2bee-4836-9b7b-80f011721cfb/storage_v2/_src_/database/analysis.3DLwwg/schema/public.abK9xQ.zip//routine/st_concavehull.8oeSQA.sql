create function st_concavehull(param_geom geometry, param_pctconvex double precision, param_allow_holes boolean DEFAULT false) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_ConcaveHull$$;

comment on function st_concavehull(geometry, double precision, boolean) is 'args: param_geom, param_pctconvex, param_allow_holes = false - Computes a possibly concave geometry that contains all input geometry vertices';

alter function st_concavehull(geometry, double precision, boolean) owner to postgres;

