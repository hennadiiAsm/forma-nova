create function st_geometricmedian(g geometry, tolerance double precision DEFAULT NULL::double precision, max_iter integer DEFAULT 10000, fail_if_not_converged boolean DEFAULT false) returns geometry
    immutable
    parallel safe
    cost 5000
    language c
as
$$ST_GeometricMedian$$;

comment on function st_geometricmedian(geometry, double precision, integer, boolean) is 'args: geom, tolerance = NULL, max_iter = 10000, fail_if_not_converged = false - Returns the geometric median of a MultiPoint.';

alter function st_geometricmedian(geometry, double precision, integer, boolean) owner to postgres;

