create function st_reduceprecision(geom geometry, gridsize double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_ReducePrecision$$;

comment on function st_reduceprecision(geometry, double precision) is 'args: g, gridsize - Returns a valid geometry with points rounded to a grid tolerance.';

alter function st_reduceprecision(geometry, double precision) owner to postgres;

