create function st_intersection(text, text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_Intersection($1::public.geometry, $2::public.geometry);  $$;

comment on function st_intersection(geometry, geometry, double precision) is 'args: geomA, geomB, gridSize = -1 - Computes a geometry representing the shared portion of geometries A and B.';

alter function st_intersection(geometry, geometry, double precision) owner to postgres;

