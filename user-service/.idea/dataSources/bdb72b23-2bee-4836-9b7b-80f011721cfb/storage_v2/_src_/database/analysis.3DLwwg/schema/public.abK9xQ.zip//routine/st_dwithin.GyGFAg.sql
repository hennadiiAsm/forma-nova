create function st_dwithin(text, text, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_DWithin($1::public.geometry, $2::public.geometry, $3);  $$;

alter function st_dwithin(geography, geography, double precision, boolean) owner to postgres;

