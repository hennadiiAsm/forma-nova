create function _st_bestsrid(geography) returns integer
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$geography_bestsrid$$;

alter function _st_bestsrid(geography, geography) owner to postgres;

