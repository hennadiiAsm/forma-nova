create function box2d(geometry) returns box2d
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_BOX2D$$;

comment on function box2d(geometry) is 'args: geom - Returns a BOX2D representing the 2D extent of a geometry.';

alter function box2d(geometry) owner to postgres;

