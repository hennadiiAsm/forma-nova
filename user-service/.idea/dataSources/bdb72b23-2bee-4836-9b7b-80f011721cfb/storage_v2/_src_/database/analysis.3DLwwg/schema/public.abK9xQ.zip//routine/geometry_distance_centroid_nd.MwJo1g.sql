create function geometry_distance_centroid_nd(geometry, geometry) returns double precision
    cost 100
    language c
as
$$gserialized_distance_nd$$;

