create function st_isvaliddetail(geom geometry, flags integer DEFAULT 0) returns valid_detail
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$isvaliddetail$$;

comment on function st_isvaliddetail(geometry, integer) is 'args: geom, flags - Returns a valid_detail row stating if a geometry is valid or if not a reason and a location.';

alter function st_isvaliddetail(geometry, integer) owner to postgres;

