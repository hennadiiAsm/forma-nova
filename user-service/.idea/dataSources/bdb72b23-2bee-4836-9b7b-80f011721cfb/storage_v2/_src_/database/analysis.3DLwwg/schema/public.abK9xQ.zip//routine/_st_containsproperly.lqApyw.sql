create function _st_containsproperly(geom1 geometry, geom2 geometry) returns boolean
    cost 100
    language c
as
$$containsproperly$$;

