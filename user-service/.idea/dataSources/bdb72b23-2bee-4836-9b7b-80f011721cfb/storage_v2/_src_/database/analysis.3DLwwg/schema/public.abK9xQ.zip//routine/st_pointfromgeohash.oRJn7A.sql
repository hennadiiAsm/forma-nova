create function st_pointfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    parallel safe
    cost 50
    language c
as
$$point_from_geohash$$;

alter function st_pointfromgeohash(text, integer) owner to postgres;

