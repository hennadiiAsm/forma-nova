create function _st_asgml(integer, geometry, integer, integer, text, text) returns text
    immutable
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asGML$$;

alter function _st_asgml(integer, geometry, integer, integer, text, text) owner to postgres;

