create function geography_spgist_leaf_consistent_nd(internal, internal) returns boolean
    cost 100
    language c
as
$$gserialized_spgist_leaf_consistent_nd$$;

