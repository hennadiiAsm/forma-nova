create function st_estimatedextent(text, text) returns box2d
    stable
    strict
    language c
as
$$gserialized_estimated_extent$$;

comment on function st_estimatedextent(text, text, text, boolean) is 'args: schema_name, table_name, geocolumn_name, parent_only - Returns the estimated extent of a spatial table.';

alter function st_estimatedextent(text, text, text, boolean) owner to postgres;

