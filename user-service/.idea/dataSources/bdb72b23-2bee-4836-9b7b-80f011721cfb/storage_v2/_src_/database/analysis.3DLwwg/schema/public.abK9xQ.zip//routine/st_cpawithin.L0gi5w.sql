create function st_cpawithin(geometry, geometry, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_CPAWithin$$;

comment on function st_cpawithin(geometry, geometry, double precision) is 'args: track1, track2, dist - Tests if the closest point of approach of two trajectoriesis within the specified distance.';

alter function st_cpawithin(geometry, geometry, double precision) owner to postgres;

