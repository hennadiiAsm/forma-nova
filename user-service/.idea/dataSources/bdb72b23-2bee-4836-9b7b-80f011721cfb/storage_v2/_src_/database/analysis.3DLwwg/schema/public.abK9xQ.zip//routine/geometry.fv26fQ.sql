create function geometry(geometry, integer, boolean) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$geometry_enforce_typmod$$;

alter function geometry(text) owner to postgres;

