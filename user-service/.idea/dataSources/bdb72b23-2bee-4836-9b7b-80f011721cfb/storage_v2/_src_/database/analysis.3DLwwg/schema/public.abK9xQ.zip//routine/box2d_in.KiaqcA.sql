create function box2d_in(cstring) returns box2d
    cost 100
    language c
as
$$BOX2D_in$$;

