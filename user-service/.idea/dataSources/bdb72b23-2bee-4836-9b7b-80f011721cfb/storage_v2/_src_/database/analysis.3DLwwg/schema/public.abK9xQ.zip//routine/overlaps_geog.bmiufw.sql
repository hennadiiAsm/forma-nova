create function overlaps_geog(gidx, gidx) returns boolean
    immutable
    strict
    language c
as
$$gserialized_gidx_gidx_overlaps$$;

alter function overlaps_geog(gidx, geography) owner to postgres;

