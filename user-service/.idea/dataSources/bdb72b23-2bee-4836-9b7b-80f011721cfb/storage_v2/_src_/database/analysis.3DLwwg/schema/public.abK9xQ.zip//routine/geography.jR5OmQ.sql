create function geography(bytea) returns geography
    cost 100
    language c
as
$$geography_from_binary$$;

