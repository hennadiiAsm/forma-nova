create function geom3d_brin_inclusion_add_value(internal, internal, internal, internal) returns boolean
    cost 100
    language c
as
$$geom3d_brin_inclusion_add_value$$;

