create function geometry_cmp(geom1 geometry, geom2 geometry) returns integer
    cost 100
    language c
as
$$lwgeom_cmp$$;

