create function postgis_typmod_srid(integer) returns integer
    immutable
    strict
    parallel safe
    language c
as
$$postgis_typmod_srid$$;

alter function postgis_typmod_srid(integer) owner to postgres;

