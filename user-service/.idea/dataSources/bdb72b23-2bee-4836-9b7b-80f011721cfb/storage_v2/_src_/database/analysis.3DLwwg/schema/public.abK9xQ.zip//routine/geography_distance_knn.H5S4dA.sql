create function geography_distance_knn(geography, geography) returns double precision
    cost 100
    language c
as
$$geography_distance_knn$$;

