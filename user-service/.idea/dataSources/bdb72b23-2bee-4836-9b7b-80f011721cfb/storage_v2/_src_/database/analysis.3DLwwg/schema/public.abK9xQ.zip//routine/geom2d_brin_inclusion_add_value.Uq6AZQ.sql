create function geom2d_brin_inclusion_add_value(internal, internal, internal, internal) returns boolean
    cost 100
    language c
as
$$geom2d_brin_inclusion_add_value$$;

