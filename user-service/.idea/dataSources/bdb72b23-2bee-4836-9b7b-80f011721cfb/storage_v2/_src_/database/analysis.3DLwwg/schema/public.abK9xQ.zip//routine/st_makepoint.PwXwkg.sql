create function st_makepoint(double precision, double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_makepoint$$;

comment on function st_makepoint(double precision, double precision, double precision, double precision) is 'args: x, y, z, m - Creates a 2D, 3DZ or 4D Point.';

alter function st_makepoint(double precision, double precision, double precision, double precision) owner to postgres;

