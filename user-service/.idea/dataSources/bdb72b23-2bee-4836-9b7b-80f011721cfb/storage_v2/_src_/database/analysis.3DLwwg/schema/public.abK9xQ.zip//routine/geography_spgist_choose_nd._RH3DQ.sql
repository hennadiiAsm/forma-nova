create function geography_spgist_choose_nd(internal, internal) returns void
    cost 100
    language c
as
$$gserialized_spgist_choose_nd$$;

