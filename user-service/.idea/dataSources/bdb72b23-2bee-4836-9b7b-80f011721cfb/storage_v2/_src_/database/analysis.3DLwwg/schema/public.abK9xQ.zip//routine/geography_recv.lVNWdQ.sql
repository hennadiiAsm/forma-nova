create function geography_recv(internal, oid, integer) returns geography
    immutable
    strict
    parallel safe
    language c
as
$$geography_recv$$;

alter function geography_recv(internal, oid, integer) owner to postgres;

