create function _st_covers(geom1 geometry, geom2 geometry) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$covers$$;

alter function _st_covers(geography, geography) owner to postgres;

