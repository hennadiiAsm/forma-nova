create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);  $$;

comment on function st_distance(geometry, geometry, bool) is 'args: g1, g2 - Returns the distance between two geometry or geography values.';

alter function st_distance(geometry, geometry, bool) owner to postgres;

