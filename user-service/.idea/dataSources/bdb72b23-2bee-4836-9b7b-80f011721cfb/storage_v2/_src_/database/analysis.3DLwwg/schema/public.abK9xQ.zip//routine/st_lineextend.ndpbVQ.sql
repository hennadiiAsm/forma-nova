create function st_lineextend(geom geometry, distance_forward double precision, distance_backward double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$geometry_line_extend$$;

comment on function st_lineextend(geometry, double precision, double precision) is 'args: line, distance_forward, distance_backward=0.0 - Returns a line with the last and first segments extended the specified distance(s).';

alter function st_lineextend(geometry, double precision, double precision) owner to postgres;

