create function st_astext(geometry) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asText$$;

alter function st_astext(geography, integer) owner to postgres;

