create function geometry_contains_nd(geometry, geometry) returns boolean
    cost 100
    language c
as
$$gserialized_contains$$;

