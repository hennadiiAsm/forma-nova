create function st_geomfromgml(text) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$SELECT public._ST_GeomFromGML($1, 0)$$;

alter function st_geomfromgml(text, integer) owner to postgres;

