create function box3d_out(box3d) returns cstring
    cost 100
    language c
as
$$BOX3D_out$$;

