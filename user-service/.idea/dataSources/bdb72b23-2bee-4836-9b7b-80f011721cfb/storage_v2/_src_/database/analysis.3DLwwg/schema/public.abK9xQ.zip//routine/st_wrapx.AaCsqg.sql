create function st_wrapx(geom geometry, wrap double precision, move double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_WrapX$$;

comment on function st_wrapx(geometry, double precision, double precision) is 'args: geom, wrap, move - Wrap a geometry around an X value.';

alter function st_wrapx(geometry, double precision, double precision) owner to postgres;

