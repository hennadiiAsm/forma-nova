create function st_lineinterpolatepoint(text, double precision) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_LineInterpolatePoint($1::public.geometry, $2);  $$;

comment on function st_lineinterpolatepoint(geography, double precision, boolean) is 'args: a_linestring, a_fraction, use_spheroid = true - Returns a point interpolated along a line at a fractional location.';

alter function st_lineinterpolatepoint(geography, double precision, boolean) owner to postgres;

