create function st_lineinterpolatepoints(text, double precision) returns geometry
    immutable
    strict
    parallel safe
    language c
as
$$ SELECT public.ST_LineInterpolatePoints($1::public.geometry, $2);  $$;

comment on function st_lineinterpolatepoints(geography, double precision, boolean, boolean) is 'args: a_linestring, a_fraction, use_spheroid = true, repeat = true - Returns points interpolated along a line at a fractional interval.';

alter function st_lineinterpolatepoints(geography, double precision, boolean, boolean) owner to postgres;

