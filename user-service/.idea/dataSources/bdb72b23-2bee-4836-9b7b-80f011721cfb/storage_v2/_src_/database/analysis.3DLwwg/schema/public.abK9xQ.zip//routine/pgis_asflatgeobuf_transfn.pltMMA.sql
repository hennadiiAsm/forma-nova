create function pgis_asflatgeobuf_transfn(internal, anyelement) returns internal
    immutable
    parallel safe
    cost 50
    language c
as
$$pgis_asflatgeobuf_transfn$$;

alter function pgis_asflatgeobuf_transfn(internal, anyelement, boolean) owner to postgres;

