create function geography(bytea) returns geography
    immutable
    strict
    parallel safe
    language c
as
$$geography_from_binary$$;

alter function geography(bytea, int4, bool) owner to postgres;

