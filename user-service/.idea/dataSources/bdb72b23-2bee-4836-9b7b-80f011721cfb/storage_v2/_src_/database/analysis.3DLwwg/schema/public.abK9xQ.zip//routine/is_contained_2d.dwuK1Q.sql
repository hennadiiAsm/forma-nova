create function is_contained_2d(geometry, box2df) returns boolean
    immutable
    strict
    parallel safe
    language c
as
$$SELECT $2 OPERATOR(public.~) $1;$$;

alter function is_contained_2d(box2df, geometry) owner to postgres;

