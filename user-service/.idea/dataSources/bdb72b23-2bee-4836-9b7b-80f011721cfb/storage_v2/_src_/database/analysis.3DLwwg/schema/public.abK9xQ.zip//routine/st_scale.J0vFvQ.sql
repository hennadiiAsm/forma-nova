create function st_scale(geometry, geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_Scale$$;

comment on function st_scale(geometry, geometry, float8, float8) is 'args: geom, factor - Scales a geometry by given factors.';

alter function st_scale(geometry, geometry, float8, float8) owner to postgres;

