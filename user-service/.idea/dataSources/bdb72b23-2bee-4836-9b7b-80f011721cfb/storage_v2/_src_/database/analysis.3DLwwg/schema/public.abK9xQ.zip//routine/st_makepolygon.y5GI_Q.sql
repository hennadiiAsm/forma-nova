create function st_makepolygon(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_makepoly$$;

comment on function st_makepolygon(geometry, geometry[]) is 'args: outerlinestring, interiorlinestrings - Creates a Polygon from a shell and optional list of holes.';

alter function st_makepolygon(geometry, geometry[]) owner to postgres;

