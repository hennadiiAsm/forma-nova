create function st_locatealong(geometry geometry, measure double precision, leftrightoffset double precision DEFAULT 0.0) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_LocateAlong$$;

comment on function st_locatealong(geometry, double precision, double precision) is 'args: geom_with_measure, measure, offset = 0 - Returns the point(s) on a geometry that match a measure value.';

alter function st_locatealong(geometry, double precision, double precision) owner to postgres;

