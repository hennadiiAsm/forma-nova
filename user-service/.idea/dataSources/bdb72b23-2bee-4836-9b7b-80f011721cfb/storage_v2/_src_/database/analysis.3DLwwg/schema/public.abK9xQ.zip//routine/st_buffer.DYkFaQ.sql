create function st_buffer(geom geometry, radius double precision, options text DEFAULT ''::text) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$buffer$$;

comment on function st_buffer(geometry, double precision, text) is 'args: g1, radius_of_buffer, buffer_style_parameters = '' - Computes a geometry covering all points within a given distance from a geometry.';

alter function st_buffer(geometry, double precision, text) owner to postgres;

