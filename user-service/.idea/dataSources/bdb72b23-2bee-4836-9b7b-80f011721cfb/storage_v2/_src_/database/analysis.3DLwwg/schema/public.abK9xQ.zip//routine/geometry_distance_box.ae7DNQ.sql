create function geometry_distance_box(geom1 geometry, geom2 geometry) returns double precision
    cost 100
    language c
as
$$gserialized_distance_box_2d$$;

