create function geometry_gist_decompress_nd(internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_decompress$$;

