create function geometry_distance_centroid(geom1 geometry, geom2 geometry) returns double precision
    cost 100
    language c
as
$$ST_Distance$$;

