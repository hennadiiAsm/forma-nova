create function _st_dfullywithin(geom1 geometry, geom2 geometry, double precision) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$LWGEOM_dfullywithin$$;

alter function _st_dfullywithin(geometry, geometry, double precision) owner to postgres;

