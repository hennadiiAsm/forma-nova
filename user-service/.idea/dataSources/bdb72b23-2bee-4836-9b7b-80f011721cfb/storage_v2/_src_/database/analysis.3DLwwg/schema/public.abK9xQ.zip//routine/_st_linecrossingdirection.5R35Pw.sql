create function _st_linecrossingdirection(line1 geometry, line2 geometry) returns integer
    cost 100
    language c
as
$$ST_LineCrossingDirection$$;

