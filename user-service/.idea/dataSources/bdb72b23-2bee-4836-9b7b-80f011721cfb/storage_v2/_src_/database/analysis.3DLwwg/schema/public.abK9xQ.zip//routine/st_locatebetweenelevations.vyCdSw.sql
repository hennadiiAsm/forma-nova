create function st_locatebetweenelevations(geometry geometry, fromelevation double precision, toelevation double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_LocateBetweenElevations$$;

comment on function st_locatebetweenelevations(geometry, double precision, double precision) is 'args: geom, elevation_start, elevation_end - Returns the portions of a geometry that lie in an elevation (Z) range.';

alter function st_locatebetweenelevations(geometry, double precision, double precision) owner to postgres;

