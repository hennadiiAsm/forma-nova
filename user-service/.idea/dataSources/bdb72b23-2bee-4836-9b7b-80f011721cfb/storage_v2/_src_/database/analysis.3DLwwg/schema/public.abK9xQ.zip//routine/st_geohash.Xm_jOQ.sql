create function st_geohash(geom geometry, maxchars integer DEFAULT 0) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ST_GeoHash$$;

alter function st_geohash(geography, integer) owner to postgres;

