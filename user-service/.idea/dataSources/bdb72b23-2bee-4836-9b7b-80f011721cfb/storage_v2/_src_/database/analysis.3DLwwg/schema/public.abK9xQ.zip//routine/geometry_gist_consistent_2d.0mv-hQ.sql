create function geometry_gist_consistent_2d(internal, geometry, integer) returns boolean
    parallel safe
    language c
as
$$gserialized_gist_consistent_2d$$;

alter function geometry_gist_consistent_2d(internal, geometry, integer) owner to postgres;

