create function postgis_typmod_dims(integer) returns integer
    immutable
    strict
    parallel safe
    language c
as
$$postgis_typmod_dims$$;

alter function postgis_typmod_dims(integer) owner to postgres;

