create function _st_maxdistance(geom1 geometry, geom2 geometry) returns double precision
    cost 100
    language c
as
$$LWGEOM_maxdistance2d_linestring$$;

