create function st_srid(geom geometry) returns integer
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_get_srid$$;

alter function st_srid(geography) owner to postgres;

