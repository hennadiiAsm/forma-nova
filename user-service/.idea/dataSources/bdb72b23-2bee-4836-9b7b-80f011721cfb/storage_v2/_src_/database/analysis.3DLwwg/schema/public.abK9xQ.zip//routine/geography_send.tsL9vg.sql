create function geography_send(geography) returns bytea
    cost 100
    language c
as
$$geography_send$$;

