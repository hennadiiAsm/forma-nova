create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    cost 5000
    language c
as
$$select public.ST_distance( public.geography($1), public.geography($2),false)$$;

comment on function st_distancesphere(geometry, geometry, double precision) is 'args: geomlonlatA, geomlonlatB, radius=6371008 - Returns minimum distance in meters between two lon/lat geometries using a spherical earth model.';

alter function st_distancesphere(geometry, geometry, double precision) owner to postgres;

