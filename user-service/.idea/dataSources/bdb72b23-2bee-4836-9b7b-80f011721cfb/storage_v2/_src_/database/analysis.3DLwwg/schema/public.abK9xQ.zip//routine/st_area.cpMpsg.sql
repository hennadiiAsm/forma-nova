create function st_area(text) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_Area($1::public.geometry);  $$;

comment on function st_area(geography, boolean) is 'args: geog, use_spheroid = true - Returns the area of a polygonal geometry.';

alter function st_area(geography, boolean) owner to postgres;

