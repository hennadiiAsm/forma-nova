create function st_makeline(geometry) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$aggregate_dummy$$;

comment on function st_makeline(geometry[]) is 'args: geoms_array - Creates a LineString from Point, MultiPoint, or LineString geometries.';

alter function st_makeline(geometry[]) owner to postgres;

