create function st_azimuth(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_azimuth$$;

comment on function st_azimuth(geography, geography) is 'args: origin, target - Returns the north-based azimuth of a line between two points.';

alter function st_azimuth(geography, geography) owner to postgres;

