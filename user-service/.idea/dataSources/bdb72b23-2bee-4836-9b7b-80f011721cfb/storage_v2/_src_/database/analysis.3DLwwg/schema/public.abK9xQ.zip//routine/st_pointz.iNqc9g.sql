create function st_pointz(xcoordinate double precision, ycoordinate double precision, zcoordinate double precision, srid integer DEFAULT 0) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$ST_PointZ$$;

comment on function st_pointz(double precision, double precision, double precision, integer) is 'args: x, y, z, srid=unknown - Creates a Point with X, Y, Z and SRID values.';

alter function st_pointz(double precision, double precision, double precision, integer) owner to postgres;

