create function geography_spgist_compress_nd(internal) returns internal
    cost 100
    language c
as
$$gserialized_spgist_compress_nd$$;

