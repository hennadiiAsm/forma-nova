create function st_generatepoints(area geometry, npoints integer) returns geometry
    strict
    parallel safe
    cost 250
    language c
as
$$ST_GeneratePoints$$;

comment on function st_generatepoints(geometry, integer) is 'args: g, npoints - Generates random points contained in a Polygon or MultiPolygon.';

alter function st_generatepoints(geometry, integer) owner to postgres;

