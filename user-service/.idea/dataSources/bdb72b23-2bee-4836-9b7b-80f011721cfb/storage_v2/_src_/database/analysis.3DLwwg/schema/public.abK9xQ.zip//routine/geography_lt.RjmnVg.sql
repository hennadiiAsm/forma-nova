create function geography_lt(geography, geography) returns boolean
    cost 100
    language c
as
$$geography_lt$$;

