create function _st_longestline(geom1 geometry, geom2 geometry) returns geometry
    cost 100
    language c
as
$$LWGEOM_longestline2d$$;

