create function contains_2d(geometry, box2df) returns boolean
    immutable
    strict
    parallel safe
    language c
as
$$SELECT $2 OPERATOR(public.@) $1;$$;

alter function contains_2d(box2df, box2df) owner to postgres;

