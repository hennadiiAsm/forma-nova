create function st_project(geom1 geometry, distance double precision, azimuth double precision) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$geometry_project_direction$$;

comment on function st_project(geometry, geometry, double precision) is 'args: g1, g2, distance - Returns a point projected from a start point by a distance and bearing (azimuth).';

alter function st_project(geometry, geometry, double precision) owner to postgres;

