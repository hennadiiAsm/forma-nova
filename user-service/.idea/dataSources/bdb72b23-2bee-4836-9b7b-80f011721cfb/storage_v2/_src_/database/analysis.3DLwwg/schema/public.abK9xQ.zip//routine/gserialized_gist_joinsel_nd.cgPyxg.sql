create function gserialized_gist_joinsel_nd(internal, oid, internal, smallint) returns double precision
    parallel safe
    language c
as
$$gserialized_gist_joinsel_nd$$;

alter function gserialized_gist_joinsel_nd(internal, oid, internal, smallint) owner to postgres;

