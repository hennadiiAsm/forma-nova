create function st_pointn(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_pointn_linestring$$;

comment on function st_pointn(geometry, integer) is 'args: a_linestring, n - Returns the Nth point in the first LineString or circular LineString in a geometry.';

alter function st_pointn(geometry, integer) owner to postgres;

