create function st_coveredby(text, text) returns boolean
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_CoveredBy($1::public.geometry, $2::public.geometry);  $$;

alter function st_coveredby(geometry, geometry) owner to postgres;

