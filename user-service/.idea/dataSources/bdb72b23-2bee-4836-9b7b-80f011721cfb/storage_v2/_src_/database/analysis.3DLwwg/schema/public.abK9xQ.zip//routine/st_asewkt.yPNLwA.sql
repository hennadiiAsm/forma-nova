create function st_asewkt(geometry) returns text
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$LWGEOM_asEWKT$$;

alter function st_asewkt(geography, integer) owner to postgres;

