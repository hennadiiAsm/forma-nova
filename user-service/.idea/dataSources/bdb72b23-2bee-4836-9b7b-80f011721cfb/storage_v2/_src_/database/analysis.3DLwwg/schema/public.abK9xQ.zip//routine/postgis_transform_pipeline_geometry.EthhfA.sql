create function postgis_transform_pipeline_geometry(geom geometry, pipeline text, forward boolean, to_srid integer) returns geometry
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$transform_pipeline_geom$$;

alter function postgis_transform_pipeline_geometry(geometry, text, boolean, integer) owner to postgres;

