create function box3d(geometry) returns box3d
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$LWGEOM_to_BOX3D$$;

alter function box3d(box2d) owner to postgres;

