create function _postgis_index_extent(tbl regclass, col text) returns box2d
    cost 100
    language c
as
$$_postgis_gserialized_index_extent$$;

