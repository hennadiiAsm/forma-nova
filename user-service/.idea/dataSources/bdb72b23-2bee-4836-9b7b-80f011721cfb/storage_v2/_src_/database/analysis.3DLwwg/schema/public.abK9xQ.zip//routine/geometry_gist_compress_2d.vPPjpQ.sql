create function geometry_gist_compress_2d(internal) returns internal
    cost 100
    language c
as
$$gserialized_gist_compress_2d$$;

