create function st_difference(geom1 geometry, geom2 geometry, gridsize double precision DEFAULT '-1.0'::numeric) returns geometry
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ST_Difference$$;

comment on function st_difference(geometry, geometry, double precision) is 'args: geomA, geomB, gridSize = -1 - Computes a geometry representing the part of geometry A that does not intersect geometry B.';

alter function st_difference(geometry, geometry, double precision) owner to postgres;

