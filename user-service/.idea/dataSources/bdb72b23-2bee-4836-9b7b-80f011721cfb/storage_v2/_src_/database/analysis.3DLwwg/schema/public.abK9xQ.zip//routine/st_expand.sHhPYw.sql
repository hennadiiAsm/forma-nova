create function st_expand(box2d, double precision) returns box2d
    immutable
    strict
    parallel safe
    cost 50
    language c
as
$$BOX2D_expand$$;

comment on function st_expand(geometry, double precision) is 'args: geom, units_to_expand - Returns a bounding box expanded from another bounding box or a geometry.';

alter function st_expand(geometry, double precision) owner to postgres;

