create function geometrytype(geometry) returns text
    immutable
    strict
    parallel safe
    language c
as
$$LWGEOM_getTYPE$$;

comment on function geometrytype(geometry) is 'args: geomA - Returns the type of a geometry as text.';

alter function geometrytype(geometry) owner to postgres;

