create function st_linelocatepoint(text, text) returns double precision
    immutable
    strict
    parallel safe
    cost 250
    language c
as
$$ SELECT public.ST_LineLocatePoint($1::public.geometry, $2::public.geometry);  $$;

comment on function st_linelocatepoint(geometry, geometry, bool) is 'args: a_linestring, a_point - Returns the fractional location of the closest point on a line to a point.';

alter function st_linelocatepoint(geometry, geometry, bool) owner to postgres;

