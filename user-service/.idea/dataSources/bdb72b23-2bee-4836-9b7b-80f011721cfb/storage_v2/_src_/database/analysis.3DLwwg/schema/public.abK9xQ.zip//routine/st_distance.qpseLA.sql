create function st_distance(text, text) returns double precision
    immutable
    strict
    parallel safe
    cost 5000
    language c
as
$$ SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);  $$;

comment on function st_distance(geography, geography, boolean) is 'args: geog1, geog2, use_spheroid = true - Returns the distance between two geometry or geography values.';

alter function st_distance(geography, geography, boolean) owner to postgres;

